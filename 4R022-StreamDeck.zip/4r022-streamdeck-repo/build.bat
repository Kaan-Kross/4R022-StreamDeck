@echo off
REM ==========================================================================
REM 4R022 StreamDeck 2.0V - .exe Derleme Script'i (Windows)
REM Kullanim: bu dosyayi cift tikla ya da "build.bat" olarak calistir.
REM ==========================================================================

echo.
echo ===============================================
echo   4R022 StreamDeck 2.0V - EXE Derleniyor
echo ===============================================
echo.

REM Gerekli paketleri kur (zaten kuruluysa atlanir)
pip install -r requirements.txt --quiet
pip install pyinstaller --quiet

REM Onceki derleme kalintilarini temizle
rmdir /s /q build 2>nul
rmdir /s /q dist 2>nul
del /q 4R022_StreamDeck.spec 2>nul

REM Tek dosya, konsolsuz, ikonlu exe olustur
pyinstaller --onefile --windowed --name "4R022_StreamDeck" ^
    --icon "assets\icon.ico" ^
    --add-data "assets;assets" ^
    4R022_StreamDeck.pyw

echo.
if exist "dist\4R022_StreamDeck.exe" (
    echo BASARILI: dist\4R022_StreamDeck.exe olusturuldu.
    echo Bu dosyayi istedigin yere tasiyip calistirabilirsin.
) else (
    echo HATA: exe olusturulamadi, yukaridaki mesajlari kontrol et.
)
echo.
pause
